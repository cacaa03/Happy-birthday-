console.log('Hello World!');

for (let i = 0; i < 1000; i++) {
  document.write("Happy Birthday!💗 Happy Birthday!💋<br>");
}

